import { useEffect, useRef, useState } from 'react'

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [navScrolled, setNavScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [typingText, setTypingText] = useState('')
  const [currentTypingIndex, setCurrentTypingIndex] = useState(0)
  const [typingDirection, setTypingDirection] = useState<'typing' | 'deleting'>('typing')
  const [typingPhraseIndex, setTypingPhraseIndex] = useState(0)
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' })
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [counters, setCounters] = useState({ clients: 0, threats: 0, uptime: 0, experts: 0 })
  const countersRef = useRef<HTMLDivElement>(null)
  const countersAnimated = useRef(false)

  const typingPhrases = [
    'Secure Your Digital Future',
    'Protect Against Cyber Threats',
    'Ethical Hacking Solutions',
    'Penetration Testing Experts',
  ]

  // Canvas animation
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationId: number
    let particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      color: string
      alpha: number
    }> = []

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const colors = ['#00FF88', '#00EAFF', '#ffffff']
    const particleCount = window.innerWidth < 768 ? 30 : 60

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.5 + 0.2,
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((p, i) => {
        p.x += p.vx
        p.y += p.vy

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = p.color
        ctx.globalAlpha = p.alpha
        ctx.fill()
        ctx.globalAlpha = 1

        // Connect particles
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[j].x - p.x
          const dy = particles[j].y - p.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 150) {
            ctx.beginPath()
            ctx.moveTo(p.x, p.y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.strokeStyle = '#00FF88'
            ctx.globalAlpha = 0.1 * (1 - dist / 150)
            ctx.lineWidth = 0.5
            ctx.stroke()
            ctx.globalAlpha = 1
          }
        }
      })

      animationId = requestAnimationFrame(animate)
    }
    animate()

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener('resize', resize)
    }
  }, [])

  // Scroll handlers
  useEffect(() => {
    const handleScroll = () => {
      setNavScrolled(window.scrollY > 50)
      setShowBackToTop(window.scrollY > 500)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Typing animation
  useEffect(() => {
    const phrase = typingPhrases[typingPhraseIndex]
    const speed = typingDirection === 'typing' ? 80 : 40

    const timer = setTimeout(() => {
      if (typingDirection === 'typing') {
        if (currentTypingIndex < phrase.length) {
          setTypingText(phrase.slice(0, currentTypingIndex + 1))
          setCurrentTypingIndex(currentTypingIndex + 1)
        } else {
          setTimeout(() => setTypingDirection('deleting'), 2000)
        }
      } else {
        if (currentTypingIndex > 0) {
          setTypingText(phrase.slice(0, currentTypingIndex - 1))
          setCurrentTypingIndex(currentTypingIndex - 1)
        } else {
          setTypingPhraseIndex((typingPhraseIndex + 1) % typingPhrases.length)
          setTypingDirection('typing')
        }
      }
    }, speed)

    return () => clearTimeout(timer)
  }, [currentTypingIndex, typingDirection, typingPhraseIndex])

  // Scroll reveal animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active')
          }
        })
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    )

    document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale').forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  // Counter animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !countersAnimated.current) {
          countersAnimated.current = true
          const targetValues = { clients: 500, threats: 1250, uptime: 99.9, experts: 45 }
          const duration = 2000
          const startTime = Date.now()

          const animate = () => {
            const elapsed = Date.now() - startTime
            const progress = Math.min(elapsed / duration, 1)
            const easeOut = 1 - Math.pow(1 - progress, 3)

            setCounters({
              clients: Math.floor(targetValues.clients * easeOut),
              threats: Math.floor(targetValues.threats * easeOut),
              uptime: Math.round(targetValues.uptime * easeOut * 10) / 10,
              experts: Math.floor(targetValues.experts * easeOut),
            })

            if (progress < 1) {
              requestAnimationFrame(animate)
            }
          }
          animate()
        }
      },
      { threshold: 0.5 }
    )

    if (countersRef.current) {
      observer.observe(countersRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setMobileMenuOpen(false)
    }
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const validateForm = () => {
    const errors: Record<string, string> = {}
    if (!formData.name.trim()) errors.name = 'Name is required'
    if (!formData.email.trim()) {
      errors.email = 'Email is required'
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      errors.email = 'Invalid email format'
    }
    if (!formData.subject.trim()) errors.subject = 'Subject is required'
    if (!formData.message.trim()) errors.message = 'Message is required'
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      setFormSubmitted(true)
      setTimeout(() => {
        setFormSubmitted(false)
        setFormData({ name: '', email: '', subject: '', message: '' })
      }, 3000)
    }
  }

  const navLinks = [
    { label: 'Home', id: 'home' },
    { label: 'About', id: 'about' },
    { label: 'Services', id: 'services' },
    { label: 'Why Us', id: 'why-us' },
    { label: 'Process', id: 'process' },
    { label: 'Tech', id: 'technologies' },
    { label: 'Testimonials', id: 'testimonials' },
    { label: 'Contact', id: 'contact' },
  ]

  const services = [
    {
      icon: 'bi-shield-lock',
      title: 'Penetration Testing',
      description: 'Comprehensive security assessments to identify and exploit vulnerabilities before attackers do.',
    },
    {
      icon: 'bi-bug',
      title: 'Vulnerability Assessment',
      description: 'Systematic scanning and analysis of your infrastructure to discover security weaknesses.',
    },
    {
      icon: 'bi-fingerprint',
      title: 'Digital Forensics',
      description: 'Expert investigation and analysis of digital evidence for incident response and legal proceedings.',
    },
    {
      icon: 'bi-incognito',
      title: 'Red Team Operations',
      description: 'Simulated real-world attacks to test your organizations detection and response capabilities.',
    },
    {
      icon: 'bi-clipboard-check',
      title: 'Compliance Auditing',
      description: 'Ensure your organization meets industry standards including ISO 27001, SOC 2, and GDPR.',
    },
    {
      icon: 'bi-cloud-check',
      title: 'Cloud Security',
      description: 'Secure your cloud infrastructure with architecture reviews, configuration audits, and monitoring.',
    },
  ]

  const processSteps = [
    {
      number: '01',
      title: 'Discovery',
      description: 'We begin by understanding your infrastructure, identifying assets, and defining the scope of engagement.',
    },
    {
      number: '02',
      title: 'Assessment',
      description: 'Our experts conduct thorough scanning and manual testing to uncover vulnerabilities and security gaps.',
    },
    {
      number: '03',
      title: 'Exploitation',
      description: 'Controlled exploitation of identified vulnerabilities to determine real-world impact and severity.',
    },
    {
      number: '04',
      title: 'Reporting',
      description: 'Comprehensive reports with executive summaries, technical findings, and actionable remediation steps.',
    },
    {
      number: '05',
      title: 'Remediation',
      description: 'We work alongside your team to fix vulnerabilities and validate that security controls are effective.',
    },
    {
      number: '06',
      title: 'Retesting',
      description: 'Follow-up testing to ensure all vulnerabilities have been properly addressed and your defenses hold.',
    },
  ]

  const technologies = [
    'Kali Linux', 'Metasploit', 'Burp Suite', 'Nmap', 'Wireshark',
    'OWASP ZAP', 'Nessus', 'Splunk', 'Snort', 'Cobalt Strike',
    'BloodHound', 'Hashcat', 'John the Ripper', 'SQLMap', 'Aircrack-ng',
  ]

  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'CISO, TechCorp',
      content: 'NexusGuard transformed our security posture. Their penetration testing uncovered critical vulnerabilities our previous vendor missed entirely.',
      rating: 5,
    },
    {
      name: 'Marcus Rivera',
      role: 'IT Director, FinServe',
      content: 'The red team exercise was eye-opening. Within hours, they demonstrated how a real attacker could breach our network. Invaluable experience.',
      rating: 5,
    },
    {
      name: 'Dr. Emily Watson',
      role: 'CTO, HealthData Systems',
      content: 'Their compliance auditing helped us achieve SOC 2 certification in record time. Professional, thorough, and incredibly knowledgeable.',
      rating: 5,
    },
  ]

  return (
    <div className="bg-dark min-h-screen">
      {/* Navbar */}
      <nav className={`navbar fixed top-0 left-0 right-0 z-50 px-4 py-4 ${navScrolled ? 'scrolled' : ''}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <a href="#home" onClick={() => scrollToSection('home')} className="flex items-center gap-3">
            <i className="bi bi-shield-lock text-2xl neon-text"></i>
            <span className="font-['Orbitron'] text-xl font-bold text-white tracking-wider">
              NEXUS<span className="neon-text">GUARD</span>
            </span>
          </a>

          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="font-['Orbitron'] text-sm text-gray-300 hover:text-[#00FF88] transition-colors duration-300"
              >
                {link.label}
              </button>
            ))}
            <button onClick={() => scrollToSection('contact')} className="btn-primary text-sm py-3 px-6">
              Get Started
            </button>
          </div>

          <button
            className="lg:hidden text-white text-2xl"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <i className={`bi ${mobileMenuOpen ? 'bi-x-lg' : 'bi-list'}`}></i>
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${mobileMenuOpen ? 'open' : ''}`}>
        <button
          className="absolute top-6 right-6 text-white text-2xl"
          onClick={() => setMobileMenuOpen(false)}
        >
          <i className="bi bi-x-lg"></i>
        </button>
        {navLinks.map((link) => (
          <button key={link.id} onClick={() => scrollToSection(link.id)}>
            {link.label}
          </button>
        ))}
      </div>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <canvas ref={canvasRef} id="canvas-container"></canvas>
        <div className="grid-overlay"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="reveal mb-6">
            <span className="inline-block px-4 py-2 rounded-full glass text-[#00FF88] text-sm font-['Orbitron'] tracking-wider">
              <i className="bi bi-shield-check mr-2"></i>
              Certified Ethical Hackers
            </span>
          </div>
          <h1 className="reveal font-['Orbitron'] text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            <span className="typing-cursor">{typingText}</span>
          </h1>
          <p className="reveal text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Elite cybersecurity solutions protecting your digital assets from evolving threats.
            We hack ethically so you can sleep securely.
          </p>
          <div className="reveal flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button onClick={() => scrollToSection('contact')} className="btn-primary">
              <i className="bi bi-rocket-takeoff"></i>
              Start Your Assessment
            </button>
            <button onClick={() => scrollToSection('services')} className="btn-outline">
              <i className="bi bi-play-circle"></i>
              Explore Services
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <div className="w-6 h-10 border-2 border-[#00FF88] rounded-full flex justify-center">
            <div className="w-1 h-2 bg-[#00FF88] rounded-full mt-2 animate-bounce"></div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section-padding bg-dark-alt">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="reveal-left">
              <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
                <i className="bi bi-info-circle mr-2"></i>ABOUT US
              </span>
              <h2 className="section-title text-left !text-left text-white mb-6">
                Defending the Digital <span className="neon-text">Frontier</span>
              </h2>
              <p className="text-gray-400 mb-6 leading-relaxed">
                Founded by former NSA operatives and elite bug bounty hunters, NexusGuard stands at the 
                forefront of cybersecurity. We dont just find vulnerabilities—we understand the mindset 
                of attackers and build defenses that hold under real-world pressure.
              </p>
              <p className="text-gray-400 mb-8 leading-relaxed">
                Our team of certified ethical hackers has secured Fortune 500 companies, government 
                agencies, and fast-growing startups. We bring military-grade precision to every engagement, 
                ensuring your digital assets remain untouchable.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <i className="bi bi-check-circle-fill text-[#00FF88] text-xl mt-1"></i>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">OSCP Certified</h4>
                    <p className="text-gray-500 text-sm">Offensive Security Certification</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <i className="bi bi-check-circle-fill text-[#00FF88] text-xl mt-1"></i>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">24/7 SOC</h4>
                    <p className="text-gray-500 text-sm">Round-the-clock monitoring</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <i className="bi bi-check-circle-fill text-[#00FF88] text-xl mt-1"></i>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">Zero Trust</h4>
                    <p className="text-gray-500 text-sm">Never trust, always verify</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <i className="bi bi-check-circle-fill text-[#00FF88] text-xl mt-1"></i>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">AI-Powered</h4>
                    <p className="text-gray-500 text-sm">Machine learning threat detection</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="reveal-right">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-[#00FF88] to-[#00EAFF] rounded-2xl opacity-20 blur-xl"></div>
                <div className="relative glass-card p-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-6 glass rounded-xl">
                      <i className="bi bi-trophy text-3xl text-[#00FF88] mb-3"></i>
                      <h3 className="font-['Orbitron'] text-2xl font-bold text-white">150+</h3>
                      <p className="text-gray-500 text-sm">Projects Completed</p>
                    </div>
                    <div className="text-center p-6 glass rounded-xl">
                      <i className="bi bi-globe text-3xl text-[#00EAFF] mb-3"></i>
                      <h3 className="font-['Orbitron'] text-2xl font-bold text-white">30+</h3>
                      <p className="text-gray-500 text-sm">Countries Served</p>
                    </div>
                    <div className="text-center p-6 glass rounded-xl">
                      <i className="bi bi-people text-3xl text-[#00FF88] mb-3"></i>
                      <h3 className="font-['Orbitron'] text-2xl font-bold text-white">45+</h3>
                      <p className="text-gray-500 text-sm">Security Experts</p>
                    </div>
                    <div className="text-center p-6 glass rounded-xl">
                      <i className="bi bi-patch-check text-3xl text-[#00EAFF] mb-3"></i>
                      <h3 className="font-['Orbitron'] text-2xl font-bold text-white">100%</h3>
                      <p className="text-gray-500 text-sm">Success Rate</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding bg-dark">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-grid mr-2"></i>OUR SERVICES
            </span>
            <h2 className="section-title text-white">
              Comprehensive <span className="neon-text">Security</span> Solutions
            </h2>
            <p className="section-subtitle">
              End-to-end cybersecurity services tailored to protect your organization from every angle.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <div
                key={service.title}
                className={`glass-card p-8 reveal-scale`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#00FF88]/20 to-[#00EAFF]/20 flex items-center justify-center mb-6">
                  <i className={`bi ${service.icon} text-2xl text-[#00FF88]`}></i>
                </div>
                <h3 className="font-['Orbitron'] text-xl font-semibold text-white mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">{service.description}</p>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="mt-6 text-[#00FF88] font-['Orbitron'] text-sm flex items-center gap-2 hover:gap-3 transition-all duration-300"
                >
                  Learn More <i className="bi bi-arrow-right"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="why-us" className="section-padding bg-dark-alt">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-award mr-2"></i>WHY CHOOSE US
            </span>
            <h2 className="section-title text-white">
              Numbers That <span className="neon-text">Speak</span>
            </h2>
            <p className="section-subtitle">
              Our track record demonstrates our commitment to excellence in cybersecurity.
            </p>
          </div>
          <div ref={countersRef} className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="reveal-scale glass-card p-8 text-center">
              <i className="bi bi-building text-4xl text-[#00FF88] mb-4"></i>
              <h3 className="font-['Orbitron'] text-4xl font-bold text-white mb-2">
                {counters.clients}+
              </h3>
              <p className="text-gray-400">Clients Protected</p>
            </div>
            <div className="reveal-scale glass-card p-8 text-center" style={{ transitionDelay: '100ms' }}>
              <i className="bi bi-shield-exclamation text-4xl text-[#00EAFF] mb-4"></i>
              <h3 className="font-['Orbitron'] text-4xl font-bold text-white mb-2">
                {counters.threats}+
              </h3>
              <p className="text-gray-400">Threats Neutralized</p>
            </div>
            <div className="reveal-scale glass-card p-8 text-center" style={{ transitionDelay: '200ms' }}>
              <i className="bi bi-activity text-4xl text-[#00FF88] mb-4"></i>
              <h3 className="font-['Orbitron'] text-4xl font-bold text-white mb-2">
                {counters.uptime}%
              </h3>
              <p className="text-gray-400">Uptime Guarantee</p>
            </div>
            <div className="reveal-scale glass-card p-8 text-center" style={{ transitionDelay: '300ms' }}>
              <i className="bi bi-person-badge text-4xl text-[#00EAFF] mb-4"></i>
              <h3 className="font-['Orbitron'] text-4xl font-bold text-white mb-2">
                {counters.exports}+
              </h3>
              <p className="text-gray-400">Security Experts</p>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="process" className="section-padding bg-dark">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-diagram-3 mr-2"></i>OUR PROCESS
            </span>
            <h2 className="section-title text-white">
              How We <span className="neon-text">Secure</span> You
            </h2>
            <p className="section-subtitle">
              Our proven methodology ensures comprehensive coverage and actionable results.
            </p>
          </div>
          <div className="relative">
            <div className="hidden lg:block timeline-line"></div>
            <div className="grid gap-8">
              {processSteps.map((step, index) => (
                <div
                  key={step.number}
                  className={`reveal flex flex-col lg:flex-row items-center gap-8 ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'lg:text-right' : 'lg:text-left'}`}>
                    <div className="process-card">
                      <span className="font-['Orbitron'] text-4xl font-bold text-[#00FF88]/30 mb-2 block">
                        {step.number}
                      </span>
                      <h3 className="font-['Orbitron'] text-xl font-semibold text-white mb-3">
                        {step.title}
                      </h3>
                      <p className="text-gray-400 leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                  <div className="hidden lg:flex timeline-dot"></div>
                  <div className="flex-1 hidden lg:block"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section id="technologies" className="section-padding bg-dark-alt">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-cpu mr-2"></i>TECHNOLOGIES
            </span>
            <h2 className="section-title text-white">
              Tools We <span className="neon-text-cyan">Master</span>
            </h2>
            <p className="section-subtitle">
              Industry-leading tools and frameworks that power our security assessments.
            </p>
          </div>
          <div className="reveal flex flex-wrap justify-center gap-4">
            {technologies.map((tech) => (
              <div key={tech} className="tech-badge text-white">
                <i className="bi bi-terminal text-[#00EAFF]"></i>
                {tech}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="section-padding bg-dark">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-chat-square-quote mr-2"></i>TESTIMONIALS
            </span>
            <h2 className="section-title text-white">
              Client <span className="neon-text">Success</span> Stories
            </h2>
            <p className="section-subtitle">
              Hear from organizations that have transformed their security with NexusGuard.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className="testimonial-card reveal"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <i key={i} className="bi bi-star-fill text-[#00FF88]"></i>
                  ))}
                </div>
                <p className="text-gray-300 mb-6 leading-relaxed italic">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00FF88] to-[#00EAFF] flex items-center justify-center text-[#050505] font-bold font-['Orbitron']">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold text-sm">
                      {testimonial.name}
                    </h4>
                    <p className="text-gray-500 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section-padding bg-dark-alt">
        <div className="max-w-7xl mx-auto px-4">
          <div className="reveal text-center mb-16">
            <span className="text-[#00FF88] font-['Orbitron'] text-sm tracking-wider mb-4 block">
              <i className="bi bi-envelope mr-2"></i>GET IN TOUCH
            </span>
            <h2 className="section-title text-white">
              Secure Your <span className="neon-text">Future</span>
            </h2>
            <p className="section-subtitle">
              Ready to assess your security posture? Contact us for a confidential consultation.
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-12">
            <div className="reveal-left">
              <div className="glass-card p-8">
                <h3 className="font-['Orbitron'] text-xl font-semibold text-white mb-6">
                  Send Us a Message
                </h3>
                {formSubmitted ? (
                  <div className="text-center py-12">
                    <i className="bi bi-check-circle-fill text-5xl text-[#00FF88] mb-4"></i>
                    <h4 className="font-['Orbitron'] text-xl text-white mb-2">Message Sent!</h4>
                    <p className="text-gray-400">We'll get back to you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <input
                        type="text"
                        placeholder="Your Name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`input-field ${formErrors.name ? 'error' : ''}`}
                      />
                      {formErrors.name && <p className="error-message">{formErrors.name}</p>}
                    </div>
                    <div>
                      <input
                        type="email"
                        placeholder="Your Email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className={`input-field ${formErrors.email ? 'error' : ''}`}
                      />
                      {formErrors.email && <p className="error-message">{formErrors.email}</p>}
                    </div>
                    <div>
                      <input
                        type="text"
                        placeholder="Subject"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className={`input-field ${formErrors.subject ? 'error' : ''}`}
                      />
                      {formErrors.subject && <p className="error-message">{formErrors.subject}</p>}
                    </div>
                    <div>
                      <textarea
                        placeholder="Your Message"
                        rows={5}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className={`input-field resize-none ${formErrors.message ? 'error' : ''}`}
                      ></textarea>
                      {formErrors.message && <p className="error-message">{formErrors.message}</p>}
                    </div>
                    <button type="submit" className="btn-primary w-full justify-center">
                      <i className="bi bi-send"></i>
                      Send Message
                    </button>
                  </form>
                )}
              </div>
            </div>
            <div className="reveal-right space-y-6">
              <div className="glass-card p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00FF88]/20 to-[#00EAFF]/20 flex items-center justify-center flex-shrink-0">
                    <i className="bi bi-geo-alt text-xl text-[#00FF88]"></i>
                  </div>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">Headquarters</h4>
                    <p className="text-gray-400">350 Cyber Avenue, Suite 900<br />San Francisco, CA 94105</p>
                  </div>
                </div>
              </div>
              <div className="glass-card p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00FF88]/20 to-[#00EAFF]/20 flex items-center justify-center flex-shrink-0">
                    <i className="bi bi-envelope text-xl text-[#00EAFF]"></i>
                  </div>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">Email</h4>
                    <p className="text-gray-400">contact@nexusguard.com<br />security@nexusguard.com</p>
                  </div>
                </div>
              </div>
              <div className="glass-card p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00FF88]/20 to-[#00EAFF]/20 flex items-center justify-center flex-shrink-0">
                    <i className="bi bi-telephone text-xl text-[#00FF88]"></i>
                  </div>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">Phone</h4>
                    <p className="text-gray-400">+1 (555) 234-5678<br />+1 (555) 876-5432</p>
                  </div>
                </div>
              </div>
              <div className="glass-card p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00FF88]/20 to-[#00EAFF]/20 flex items-center justify-center flex-shrink-0">
                    <i className="bi bi-clock text-xl text-[#00EAFF]"></i>
                  </div>
                  <div>
                    <h4 className="font-['Orbitron'] text-white font-semibold mb-1">Availability</h4>
                    <p className="text-gray-400">24/7 Security Operations<br />Emergency Response Available</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark border-t border-white/5 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <a href="#home" onClick={() => scrollToSection('home')} className="flex items-center gap-3 mb-4">
                <i className="bi bi-shield-lock text-2xl neon-text"></i>
                <span className="font-['Orbitron'] text-xl font-bold text-white tracking-wider">
                  NEXUS<span className="neon-text">GUARD</span>
                </span>
              </a>
              <p className="text-gray-400 leading-relaxed max-w-md">
                Elite cybersecurity solutions for modern enterprises. We protect what matters most 
                through ethical hacking, penetration testing, and advanced threat detection.
              </p>
              <div className="flex gap-4 mt-6">
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-[#00FF88] hover:bg-[#00FF88] hover:text-[#050505] transition-all duration-300">
                  <i className="bi bi-twitter-x"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-[#00FF88] hover:bg-[#00FF88] hover:text-[#050505] transition-all duration-300">
                  <i className="bi bi-linkedin"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-[#00FF88] hover:bg-[#00FF88] hover:text-[#050505] transition-all duration-300">
                  <i className="bi bi-github"></i>
                </a>
                <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-[#00FF88] hover:bg-[#00FF88] hover:text-[#050505] transition-all duration-300">
                  <i className="bi bi-discord"></i>
                </a>
              </div>
            </div>
            <div>
              <h4 className="font-['Orbitron'] text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-3">
                {navLinks.slice(1, 5).map((link) => (
                  <li key={link.id}>
                    <button
                      onClick={() => scrollToSection(link.id)}
                      className="text-gray-400 hover:text-[#00FF88] transition-colors duration-300 text-sm"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-['Orbitron'] text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-[#00FF88] transition-colors duration-300 text-sm">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FF88] transition-colors duration-300 text-sm">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FF88] transition-colors duration-300 text-sm">Cookie Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FF88] transition-colors duration-300 text-sm">Responsible Disclosure</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/5 pt-8 text-center">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} NexusGuard. All rights reserved. Secured with <i className="bi bi-heart-fill text-[#00FF88] mx-1"></i> and military-grade encryption.
            </p>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      <button
        onClick={scrollToTop}
        className={`back-to-top ${showBackToTop ? 'visible' : ''}`}
        aria-label="Back to top"
      >
        <i className="bi bi-arrow-up text-[#050505] text-lg font-bold"></i>
      </button>
    </div>
  )
}

export default App
